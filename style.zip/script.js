// JavaScript file for Pet Food Intolerances application
// This file will contain the application logic

// Sample ingredient scanner function
function scanIngredients(ingredients, intolerances) {
  const matched = [];
  ingredients.forEach(ingredient => {
    if (intolerances.includes(ingredient.toLowerCase())) {
      matched.push(ingredient);
    }
  });
  console.log("Matches found:", matched);
  return matched;
}

// Example usage (you can change these later):
const userIngredients = ["Chicken", "Corn", "Beef", "Carrots"];
const userIntolerances = ["corn", "soy", "wheat"];

scanIngredients(userIngredients, userIntolerances);

function handleScan() {
  const ingredientsInput = document.getElementById("ingredients").value;
  const intolerancesInput = document.getElementById("intolerances").value;

  const ingredients = ingredientsInput.split(",").map(i => i.trim().toLowerCase());
  const intolerances = intolerancesInput.split(",").map(i => i.trim().toLowerCase());

  const matches = scanIngredients(ingredients, intolerances);

  const resultsDiv = document.getElementById("results");
  if (matches.length > 0) {
    resultsDiv.innerHTML = "⚠️ Intolerances found: " + matches.join(", ");
    resultsDiv.style.color = "red";
  } else {
    resultsDiv.innerHTML = "✅ No intolerances detected!";
    resultsDiv.style.color = "green";
  }
} 